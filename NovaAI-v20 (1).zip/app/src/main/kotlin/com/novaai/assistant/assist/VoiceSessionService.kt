package com.novaai.assistant.assist

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.novaai.assistant.MainActivity
import com.novaai.assistant.R
import com.novaai.assistant.ai.ChatEngine
import com.novaai.assistant.data.Store
import com.novaai.assistant.utils.Perms
import com.novaai.assistant.ai.LlmClient
import com.novaai.assistant.voice.CloudListener
import com.novaai.assistant.voice.GeminiLive
import com.novaai.assistant.voice.LiveListener
import com.novaai.assistant.widget.OrbOverlayService
import com.novaai.assistant.voice.Tts
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch

object Session {
    /** True while the always-on mic is running. */
    val active = MutableStateFlow(false)
    /** True while the person is speaking. */
    val hearing = MutableStateFlow(false)
    /** True while a command is being worked on or answered. */
    val busy = MutableStateFlow(false)
    /** True while Nova is talking. */
    val speaking = MutableStateFlow(false)
    /** A short note about what the live connection is doing (or why it failed). */
    val info = MutableStateFlow("")
    /** True when the person pressed Mute on the live screen. */
    val muted = MutableStateFlow(false)
    /** True while Nova can SEE the screen (a fresh picture is sent about once a second). */
    val screenShare = MutableStateFlow(false)
    /** The last thing Nova heard you say, so you can check it understood you. */
    val heard = MutableStateFlow("")

    fun setScreenShare(on: Boolean) { Store.putBool("screen_share", on); screenShare.value = on }
}

/**
 * The always-on mic. Once started it keeps listening, runs every command it hears,
 * and only stops when the person turns it off (notification Stop, orb, mic button or "mic off").
 */
class VoiceSessionService : Service() {
    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var live: LiveListener? = null
    private var cloud: CloudListener? = null
    private var gl: GeminiLive? = null
    private fun hasEars() = live != null || cloud != null || gl != null
    private fun earsPause() { live?.pause(); cloud?.pause(); gl?.pause() }
    private fun earsResume() { live?.resume(); cloud?.resume(); gl?.resume() }
    private fun earsStop() { live?.stop(); live = null; cloud?.stop(); cloud = null; gl?.stop(); gl = null }
    private fun doResume() { Session.busy.value = false; if (!Session.muted.value) earsResume() }
    private var wake: PowerManager.WakeLock? = null
    private var resumeTimeout: Runnable? = null
    private var starting = false

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            Store.setHey(false)
            stopSelf()
            return START_NOT_STICKY
        }
        if (!goForeground() || !Perms.has(this, Manifest.permission.RECORD_AUDIO)) {
            // Android blocked starting the mic from the background, or mic permission is missing.
            Session.active.value = false
            stopSelf()
            return START_NOT_STICKY
        }
        inst = this
        Session.active.value = true
        if (!hasEars() && !starting) { starting = true; main.postDelayed({ starting = false; if (inst === this && !hasEars()) begin() }, 400) }
        return START_STICKY
    }

    private fun goForeground(): Boolean {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Nova live mic", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 1, Intent(this, VoiceSessionService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val open = PendingIntent.getActivity(
            this, 2, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_stat_nova)
            .setContentTitle("Nova is listening")
            .setContentText("Mic stays on until you tap Stop")
            .setOngoing(true)
            .setContentIntent(open)
            .addAction(R.drawable.ic_stat_nova, "Stop", stop)
            .build()
        return try {
            if (Build.VERSION.SDK_INT >= 30) startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            else startForeground(ID, n)
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun begin() {
        Session.active.value = true
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "nova:mic").apply {
            setReferenceCounted(false)
            runCatching { acquire() }
        }
        val fatal: (String) -> Unit = { msg ->
            Tts.speak(this, msg)
            Store.setHey(false)
            stopSelf()
        }
        if (Store.str("k_gemini").isNotBlank()) {
            // Best: Gemini Live, a real-time voice call. Falls back below if it isn't available.
            val g = GeminiLive(
                ctx = this,
                onHearing = { Session.hearing.value = it },
                onSpeaking = { Session.speaking.value = it },
                onBusy = { Session.busy.value = it },
                onUnavailable = { gl?.stop(); gl = null; Session.info.value = Session.info.value + " → normal mode"; startClassic(fatal) },
                onFatal = fatal
            )
            gl = g
            try { g.start() } catch (e: Exception) {
                gl = null; Session.info.value = "Live start failed: " + (e.message ?: "")
                startClassic(fatal)
            }
        } else startClassic(fatal)
        if (Perms.overlay(this)) OrbOverlayService.start(this)
    }

    private fun startClassic(fatal: (String) -> Unit) {
        if (LlmClient.provider() != null) {
            val c = CloudListener(onText = { heard(it) }, onHearing = { Session.hearing.value = it }, onFatal = fatal)
            cloud = c
            c.start()
        } else {
            val l = LiveListener(ctx = this, onText = { heard(it) }, onHearing = { Session.hearing.value = it }, onFatal = fatal)
            live = l
            l.start()
        }
    }

    private fun heard(raw: String) {
        if (!hasEars()) return
        val low = raw.lowercase().trim()
        val needWake = Store.bool("need_wake")
        val hit = WAKES.firstOrNull { low.contains(it) }
        if (needWake && hit == null) return
        var text = low
        if (hit != null && (needWake || low.startsWith(hit))) {
            text = low.substring(low.indexOf(hit) + hit.length).trim().trimStart(',', '.', '।', ' ')
        }
        if (text.isEmpty()) {
            earsPause()
            Tts.speak(this, "Yes?") { resumeSoon(0) }
            armResume()
            return
        }
        earsPause()
        Session.busy.value = true
        armResume()
        scope.launch {
            val r = ChatEngine.send(this@VoiceSessionService, text, speak = true, onSpoken = { resumeSoon(0) })
            if (!r.spoken) resumeSoon(0)
        }
    }

    /** If speech never reports back, start listening again anyway. */
    private fun armResume() {
        resumeTimeout?.let { main.removeCallbacks(it) }
        val r = Runnable { doResume() }
        resumeTimeout = r
        main.postDelayed(r, 30000)
    }

    private fun resumeSoon(ms: Long) {
        resumeTimeout?.let { main.removeCallbacks(it) }
        main.postDelayed({ doResume() }, ms)
    }

    override fun onDestroy() {
        earsStop()
        com.novaai.assistant.control.ScreenCaptureService.stop(this)
        Session.setScreenShare(false)
        inst = null
        Session.busy.value = false
        Session.speaking.value = false
        Session.muted.value = false
        Session.info.value = ""
        resumeTimeout?.let { main.removeCallbacks(it) }
        scope.cancel()
        runCatching { wake?.let { if (it.isHeld) it.release() } }
        Session.active.value = false
        Session.hearing.value = false
        super.onDestroy()
    }

    companion object {
        private const val CH = "nova_live"
        private const val ID = 2004
        const val ACTION_STOP = "nova.STOP_MIC"
        @Volatile private var inst: VoiceSessionService? = null

        fun setMuted(m: Boolean) {
            Session.muted.value = m
            inst?.let { if (m) it.earsPause() else it.earsResume() }
        }
        private val WAKES = listOf(
            "hey nova", "hi nova", "ok nova", "okay nova", "nova",
            "হেই নোভা", "হে নোভা", "হ্যালো নোভা", "ওকে নোভা", "নোভা"
        )

        fun start(ctx: Context) {
            runCatching { ctx.startForegroundService(Intent(ctx, VoiceSessionService::class.java)) }
        }

        /** User turned the mic off: remember that, so it doesn't come back by itself. */
        fun stop(ctx: Context) {
            Store.setHey(false)
            ctx.stopService(Intent(ctx, VoiceSessionService::class.java))
        }
    }
}
