package com.novaai.assistant.widget

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.*
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.Toast
import androidx.core.app.NotificationCompat
import com.novaai.assistant.R
import com.novaai.assistant.assist.Session
import com.novaai.assistant.assist.VoiceSessionService
import com.novaai.assistant.data.Store
import com.novaai.assistant.utils.Perms
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.combine

/** Draggable glowing mini orb. Tap = turn the always-on mic on/off, long-press = hide the orb. */
class OrbOverlayService : Service() {
    private var wm: WindowManager? = null
    private var orb: OrbView? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForeground()
        if (intent?.action == ACTION_HIDE || !Perms.overlay(this)) {
            if (!Perms.overlay(this)) Toast.makeText(this, "Allow 'Display over other apps' for Nova", Toast.LENGTH_LONG).show()
            stopSelf(); return START_NOT_STICKY
        }
        if (orb == null) showOrb()
        if (intent?.action == ACTION_LISTEN && !Session.active.value) toggleMic()
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("nova_orb", "Mini orb", NotificationManager.IMPORTANCE_MIN))
        val n = NotificationCompat.Builder(this, "nova_orb")
            .setSmallIcon(R.drawable.ic_stat_nova).setContentTitle("Nova mini orb")
            .setContentText("Tap the orb: mic on/off. Long-press: hide").setOngoing(true).build()
        try {
            if (Build.VERSION.SDK_INT >= 34) startForeground(2002, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            else startForeground(2002, n)
        } catch (e: Exception) {
            stopSelf()
        }
    }

    private fun showOrb() {
        val w = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        wm = w
        val size = (64 * resources.displayMetrics.density).toInt()
        val lp = WindowManager.LayoutParams(
            size, size, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 40; y = 400 }
        lateinit var v: OrbView
        v = OrbView(this, onTap = { toggleMic() }, onLong = { stopSelf() }, onDrag = { dx, dy ->
            lp.x += dx; lp.y += dy
            runCatching { w.updateViewLayout(v, lp) }
        })
        orb = v
        w.addView(v, lp)
        // green while the mic is on, brighter ring while you are speaking
        scope.launch {
            Session.active.combine(Session.hearing) { a, h -> a to h }.collect { (a, h) ->
                v.live = a; v.listening = h
            }
        }
    }

    private fun toggleMic() {
        if (Session.active.value) { VoiceSessionService.stop(this); return }
        if (!Perms.has(this, Manifest.permission.RECORD_AUDIO)) {
            Toast.makeText(this, "Open Nova once and allow the microphone", Toast.LENGTH_LONG).show(); return
        }
        Store.setHey(true)
        VoiceSessionService.start(this)
    }

    override fun onDestroy() {
        scope.cancel()
        orb?.let { o -> runCatching { wm?.removeView(o) } }
        orb = null
        super.onDestroy()
    }

    companion object {
        const val ACTION_SHOW = "nova.SHOW"
        const val ACTION_HIDE = "nova.HIDE"
        const val ACTION_LISTEN = "nova.LISTEN"
        fun start(ctx: Context, listen: Boolean = false) {
            val i = Intent(ctx, OrbOverlayService::class.java).setAction(if (listen) ACTION_LISTEN else ACTION_SHOW)
            runCatching { ctx.startForegroundService(i) }
        }
    }
}

private class OrbView(
    ctx: Context,
    val onTap: () -> Unit,
    val onLong: () -> Unit,
    val onDrag: (Int, Int) -> Unit
) : View(ctx) {
    var listening = false
        set(v) { field = v; invalidate() }
    var live = false
        set(v) { field = v; invalidate() }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var lastX = 0f
    private var lastY = 0f
    private var moved = false
    private var longFired = false
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
    private val longRun = Runnable { if (!moved) { longFired = true; onLong() } }

    override fun onDraw(c: Canvas) {
        val r = width / 2f
        val core = if (live) 0xFF2EE6B0.toInt() else 0xFF8B5CFF.toInt()
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(r, r, r, intArrayOf(0xFFEAF4FF.toInt(), core, 0x0025C2F0), floatArrayOf(.25f, .65f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(r, r, r, p)
        p.shader = null
        p.style = Paint.Style.STROKE; p.strokeWidth = if (listening) 8f else 3f; p.color = if (listening) 0xFFFFFFFF.toInt() else 0xFF25C2F0.toInt()
        c.drawCircle(r, r, r * .68f, p)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = e.rawX; lastY = e.rawY; moved = false; longFired = false
                postDelayed(longRun, ViewConfiguration.getLongPressTimeout().toLong())
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = (e.rawX - lastX).toInt(); val dy = (e.rawY - lastY).toInt()
                if (!moved && (Math.abs(dx) > slop || Math.abs(dy) > slop)) { moved = true; removeCallbacks(longRun) }
                if (moved) { onDrag(dx, dy); lastX = e.rawX; lastY = e.rawY }
            }
            MotionEvent.ACTION_UP -> { removeCallbacks(longRun); if (!moved && !longFired) { performClick(); onTap() } }
            MotionEvent.ACTION_CANCEL -> removeCallbacks(longRun)
        }
        return true
    }

    override fun performClick(): Boolean = super.performClick()
}
